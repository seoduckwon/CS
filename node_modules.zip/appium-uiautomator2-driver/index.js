import {install} from 'source-map-support';

install();

import {AndroidUiautomator2Driver} from './lib/driver';

export {AndroidUiautomator2Driver};
export default AndroidUiautomator2Driver;
